# iTerm2 Puppet Module for Boxen

Requires the following boxen modules:

* `boxen`

## Usage

```puppet
# Stable release
include iterm2::stable

# Dev release
include iterm2::dev
```
