# Heroku Puppet Module for Boxen

Requires the following boxen modules:

* `boxen`

## Usage

```puppet
heroku::plugin { 'accounts':
  source => 'ddollar/heroku-accounts'
}
```
