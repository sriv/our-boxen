# Opera Puppet Module for Boxen

[![Build Status](https://travis-ci.org/createdbypete/puppet-opera.png?branch=master)](https://travis-ci.org/createdbypete/puppet-opera)

Install [Opera](http://www.opera.com/), the alternative web browser

## Usage

```puppet
include opera

# for Opera Next
include opera::next
```

## Required Puppet Modules

* `boxen >= 2.3.1`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
